package com.raju.movies.controller;

import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.raju.movies.entity.Movie;
import com.raju.movies.service.MovieService;

@RestController
@RequestMapping("api/v1/movies")
public class MovieController {
	
	@Autowired
	private MovieService service;
	
	@GetMapping("/all")
	@ResponseStatus(HttpStatus.OK)
	public List<Movie> getallmovies() {
		return service.allMovies();
	}
	
	@GetMapping("/{id}")
	public Optional<Movie> getMovieById(@PathVariable ObjectId id) {
		return service.getMovieByIDD(id);
	}
	
	@GetMapping("/imdbid/{imdbId}")
	public Optional<Movie> getMovieByImdb(@PathVariable String imdbId) {
		return service.getMovieByImdbIDD(imdbId);
	}

}
