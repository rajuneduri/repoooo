package com.raju.movies.service;

import java.util.List;
import java.util.Optional;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.raju.movies.entity.Movie;
import com.raju.movies.repository.MovieRepository;

@Service
public class MovieService {
	
	@Autowired
	private MovieRepository repo;
	
	public List<Movie> allMovies(){
		return repo.findAll();
	}
	public Optional<Movie> getMovieByIDD(ObjectId idd) {
		return repo.findById(idd);
	}
	public Optional<Movie> getMovieByImdbIDD(String idd) {
		return repo.findByImdbId(idd);
	}

}
