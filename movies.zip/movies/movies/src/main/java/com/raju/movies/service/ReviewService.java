package com.raju.movies.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.raju.movies.entity.Movie;
import com.raju.movies.entity.Reviews;
import com.raju.movies.repository.ReviewRepository;

@Service
public class ReviewService {

	@Autowired
	private ReviewRepository repos;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	public Reviews createReview(String reviewBody,String imdbId) {
		Reviews review=repos.insert(new Reviews(reviewBody));
		
		mongoTemplate.update(Movie.class)
		.matching(Criteria.where("imdbId").is(imdbId))
		.apply(new Update().push("reviewIds",review))
		.first();
		
		
		return review;
		
	}
}
